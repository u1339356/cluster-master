/* -*- Mode: C; c-basic-offset:4 ; indent-tabs-mode:nil -*- */
/*
 * Copyright (c) 2015      Intel, Inc. All rights reserved.
 * $COPYRIGHT$
 *
 * Additional copyrights may follow
 *
 * $HEADER$
 */

#ifndef OPAL_MCA_COMMON_LIBFABRIC_H
#define OPAL_MCA_COMMON_LIBFABRIC_H

OPAL_DECLSPEC int mca_common_libfabric_register_mca_variables(void);

#endif /* OPAL_MCA_COMMON_LIBFABRIC_H */
